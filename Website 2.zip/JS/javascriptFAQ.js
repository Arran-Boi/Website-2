//FAQ JS
//each page has its own separate JS file to reduce clutter and interference 

//JQUERY: AJAX
//Link: https://www.tutorialsteacher.com/jquery/jquery-ajax-introduction

let json_url = "/JSON/faqs.json";
//Use Jquery method to load Json file
$.getJSON(
	json_url,
	function (data) { //Get json file and assign it to "data"
		//Loop through all the questions and extract its question & answer
		console.log(data);
		$.each(data, function (i, question) { //i: index, question: object
			//Extract question and answer display on webpage
			let node = '<div class="col-12 col-md-6 p-2">' +
				'<div class="bg-warning h-100 p-2">' +
				'<h4>' + question.question + '</h4>' +
				'<p>' + question.answer + '</p>' +
				'<div>' +
				'</div>';
			$('#questions').append(node)
		});
	}
);

//Filter or search function
$("#search-box").on("keyup", function () {
	//Get entered keywords
	let keywords = $(this).val().toLowerCase();
	//Loop through all questions (wrapped in <div> element inside "questions" section),
	// find all question/answer containing keywords
	$("#questions div").filter(function () {
		//Keep displaying all element containing the keyword
		$(this).toggle($(this).html().toLowerCase().indexOf(keywords) > -1); //indexOf(keywords) returns "-1"
		//if not containing the keyword
	});
});