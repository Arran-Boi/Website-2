// extension page JS
//each page has its own separate JS file to reduce clutter and interference 

//JQUERY: Accordion Component
//Initially hide all content-demo-content
$('.content-demo-area div').hide();
//Loop through all buttons in "btn-demo-area" and add click event to each of them.
$('.btn-demo-area button').on('click', function () {
    //Set all button background color to white
    $('.btn-demo-area button').css('background-color', 'white');
    //Set this button background color to orange
    $(this).css('background-color', 'orange');
    //Hide all content-demo-content
    $('.content-demo-area div').hide();
    //Show only the selected demo area
    let index = $(this).index();
    $('.content-demo-area div').eq(index).show(1000);
});

// $("path, circle").mouseleave(function(e) {
//     $('#info-box').css('display','none');
//   });

//   $(document).mousemove(function(e) {
//     $('#info-box').css('top',e.pageY-$('#info-box').height()-30);
//     $('#info-box').css('left',e.pageX-($('#info-box').width())/2);
//   }).mouseover();

//   var ios = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
//   if(ios) {
//     $('a').on('click touchend', function() { 
//       var link = $(this).attr('href');   
//       window.open(link,'_blank');
//       return false;
//     });
//   }



// $('#NZ-HKB').mouseover( function(e) {
//   console.log(e.target.getAttribute('title'))
// })



// $('path').mouseover( function(e) {
//   console.log(e.target.getAttribute('title'))
// })



$('path').mouseover(function (e) {

    // grab the title attribiute of the active path
    var title = $(this).attr('title')

    // use jquery to set the inner html to this value
    $('#info-box').html(title)

    // dislay it nicely (using the sample code above)
    $('#info-box').css('display', 'block')
    $('#info-box').css('top', e.pageY - $('#info-box').height() - 30);
    $('#info-box').css('left', e.pageX - ($('#info-box').width()) / 2);
})


// make sure the info-box disappears when on mouseout.
$("path").mouseleave(function () {
    $('#info-box').css('display', 'none');
});